<!DOCTYPE html>
<?php
	include 'connect.php';
?>
<html>
<head>
<title>  Open connection to ECC MariaDB server </title>
</head>
<body>
<h2>Personal Quarantine Admin</h2>
<h4>Insert Symptoms</h4>
<?php
if (isset ($_POST['submit'])) // If submit button pressed
{
    $passwd = $_POST['password'];
    $symptom_name = $_POST['symptom_name'];
	$conn = new mysqli (DB_HOST, DB_USER, $passwd, DB_NAME, DB_PORT);

	if ($conn->connect_errno) { echo $conn->connect_error; }

	$sql = "INSERT into Symptoms (name) VALUES ('".$symptom_name."')";
	if ($conn->query($sql) === TRUE) {
		echo "New symptom added successfully.";
	  } else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	  }
	$conn->close();
	unset ($_POST); 
}
else
{
?> 
	<form method="post" action="main.php">
		Enter password: <input type="password" name="password"><br>
		Enter symptom: <input type="text" name="symptom_name"><br>
		<input type="submit" name="submit">
	</form>
<?php
}
?>
</body>
</html>
