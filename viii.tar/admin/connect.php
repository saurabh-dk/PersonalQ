<?php
// Updated Nov.2020 rr
define ("DB_HOST", "ecc-db.csuchico.edu"); // hostname of DB server
define ("DB_USER", "skulkarni1@ecc-db");            // Username
define ("DB_NAME", "skulkarni1");              // Database name
define ("DB_PORT", 3306);                  // port number
define ("PASS", "Password!");              // Password to be filled by POST
?>  
