<?php
// Updated Nov.2020 rr
$DB_HOST = "ecc-db.csuchico.edu"; // hostname of DB server
$DB_USER = "skulkarni1@ecc-db";            // Username
$DB_NAME = "skulkarni1";

?>
